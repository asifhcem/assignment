import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';
import { DataCommunicationService } from '../../data-communication.service';

@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.scss']
})

export class CityComponent implements OnInit {
  city1 :string = 'London';
  city2 :string = 'LiverPool';
  city3 :string = 'Belfast';
  city4 :string = 'Glasgow';
  city5 :string = 'Birmingham';
  cities :any = []
  constructor( private dataCommunication : DataCommunicationService,private router : Router) { }

  ngOnInit(): void {
    this.getTemp();
  }
  getTemp(){
    let firstCity = this.dataCommunication.getCityTemp(this.city1);
    let second = this.dataCommunication.getCityTemp(this.city2);
    let third = this.dataCommunication.getCityTemp(this.city3);
    let fourth = this.dataCommunication.getCityTemp(this.city4);
    let fifth = this.dataCommunication.getCityTemp(this.city5);
    // fecthing data for 5 different cities using RxJS ForkJoin 
    forkJoin([firstCity,second,third,fourth,fifth]).subscribe((results) =>{
      //contains City's details
      this.cities =results;
    
    });
     
  
   
  }
  //navigate to forecast page and set city name
  getDetails(cityName:string){
    this.dataCommunication.city=cityName;
    this.router.navigateByUrl('/foreCast');
  }
}
