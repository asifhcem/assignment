import { ThrowStmt } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { DataCommunicationService } from '../../data-communication.service';

@Component({
  selector: 'app-fore-cast',
  templateUrl: './fore-cast.component.html',
  styleUrls: ['./fore-cast.component.scss']
})
export class ForeCastComponent implements OnInit {
  city :string ='';
  Forecast :any=[];
  tempList: any;
  instruction : boolean = false;
  constructor(private dataCommunication : DataCommunicationService) { 
    
  }

  ngOnInit(): void {
    this.city = this.dataCommunication.city;
    if(this.city){
      //flag to show header message on forecast page conditionally
      this.instruction = true;
    }
    //call function to Fetch Forecast
    this.getDetails(this.city);
  }
// fetch data to get Forecast for 5 days
  getDetails(cityName:string){
    this.dataCommunication.city=cityName;
    this.dataCommunication.cityForeCast(cityName).subscribe(data=>{
      console.log(data);
      this.Forecast =data;
      //List constaining tmperature details,units are not sure .So have set in centigrate.
      this.tempList = this.Forecast['list'];
      
    })
}
}
