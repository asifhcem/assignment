import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {environment} from '../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class DataCommunicationService {
  city='';
  constructor(private http : HttpClient,) { }
  getCityTemp(town : string){
    return this.http.get(environment.baseUrl + 'weather?q='+ town +','+ 'uk&appid='+environment.key);
  }
   cityForeCast(cityName:string){
     return this.http.get(environment.baseUrl + 'forecast?q='+ this.city+ '&appid=' + environment.key);
   }
}
