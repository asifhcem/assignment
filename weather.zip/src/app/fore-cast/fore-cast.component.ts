import { ThrowStmt } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { DataCommunicationService } from '../data-communication.service';

@Component({
  selector: 'app-fore-cast',
  templateUrl: './fore-cast.component.html',
  styleUrls: ['./fore-cast.component.scss']
})
export class ForeCastComponent implements OnInit {
  city :string ='';
  Forecast :any=[];
  tempList: any;
  instruction : boolean = false;
  constructor(private dataCommunication : DataCommunicationService) { 
    
  }

  ngOnInit(): void {
    this.city = this.dataCommunication.city;
    if(this.city){
      this.instruction = true;
console.log(this.instruction);
    }
    this.getDetails(this.city);
  }
  getDetails(cityName:string){
    this.dataCommunication.city=cityName;
    this.dataCommunication.cityForeCast(cityName).subscribe(data=>{
      console.log(data);
      this.Forecast =data;
      this.tempList = this.Forecast['list'];
      // this.tempList.array.forEach(el => {
      //   if(el.dt_txt.includes('21.'))
        
      // });

      //this.router.navigateByUrl('/foreCast');
    })
}
}
