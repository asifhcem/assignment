import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { CityComponent } from './component/city/city.component';
import { ForeCastComponent } from './component/fore-cast/fore-cast.component';

const routes: Routes = [
  {path: '', component:CityComponent},
  {path:'foreCast',component:ForeCastComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
